pref("testPref.unsticky.bool", true);
pref("testPref.sticky.bool", false, sticky);
