#filter dumbComments emptyLines

// Do not add anything else to this file. Additions should go in all.js.

#include init/all.js
