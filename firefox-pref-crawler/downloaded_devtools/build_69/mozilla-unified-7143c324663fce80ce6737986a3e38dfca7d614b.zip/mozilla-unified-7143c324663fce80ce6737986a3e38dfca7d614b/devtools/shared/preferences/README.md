# How is devtools-shared loaded?

This preference file is included via modules/libpref/greprefs.js which guarantees it will
be loaded on all distributions, including xpcshell binary.
