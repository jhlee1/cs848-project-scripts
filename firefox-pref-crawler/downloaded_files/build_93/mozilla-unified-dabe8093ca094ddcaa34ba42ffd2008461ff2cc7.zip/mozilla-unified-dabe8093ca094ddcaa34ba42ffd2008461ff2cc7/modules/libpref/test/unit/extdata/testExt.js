pref("testPref.bool2", true);
pref("testExtPref.bool", true);
