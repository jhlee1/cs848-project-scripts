user_pref("testPref.bool1", true);
user_pref("testPref.bool2", false);
user_pref("testPref.int1", 23);
user_pref("testPref.int2", -1236);
user_pref("testPref.char1", "_testPref");
user_pref("testPref.char2", "älskar");
