// testPrefLocked.js defined this pref as a locked pref.
// Changing a locked pref has no effect.
user_pref("testPref.locked.int", 555);
