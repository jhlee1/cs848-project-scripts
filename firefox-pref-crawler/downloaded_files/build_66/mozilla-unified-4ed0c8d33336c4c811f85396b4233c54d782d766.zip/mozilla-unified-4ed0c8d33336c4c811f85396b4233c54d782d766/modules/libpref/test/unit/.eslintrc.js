"use strict";

module.exports = {
  "extends": [
    "plugin:mozilla/xpcshell-test",
  ]
};
