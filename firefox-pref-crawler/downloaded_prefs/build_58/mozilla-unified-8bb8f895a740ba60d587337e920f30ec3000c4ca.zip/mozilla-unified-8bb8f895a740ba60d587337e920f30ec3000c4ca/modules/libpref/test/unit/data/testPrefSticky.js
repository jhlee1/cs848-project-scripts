pref("testPref.unsticky.bool", true);
sticky_pref("testPref.sticky.bool", false);
