pref("testPref.unlocked.int", 333);
pref("testPref.locked.int", 444, locked);
